package utils;

public enum E_Gender {

	M,F;
}
